<?php
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Scommerce_BreezeGoogleTagManagerPro',
    __DIR__
);
